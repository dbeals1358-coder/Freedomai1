# Unbound AI Studio (Android starter)

An Android Studio Kotlin/Jetpack Compose project.

## Implemented
- Dark themed Generate/Edit tabs
- Text prompt input (AI engine **not connected**)
- Pick a photo from Android's photo picker
- Adjust brightness and saturation
- Save edited copies in Pictures/Unbound AI Studio

## To run
Open this folder in Android Studio, allow Gradle to sync, then run on an Android device (Android 10+). This archive contains source code, not an installable APK. Build verification has not been performed in this environment.

## Next steps
Connect an image-generation and image-editing model. Cloud models incur compute costs; local models require compatible phone hardware and substantial storage. Add safety controls against nonconsensual intimate imagery and sexual content involving minors.
